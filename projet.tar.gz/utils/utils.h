#ifndef __UTILS_H__
#define __UTILS_H__

#include <inttypes.h>

// Convertit une chaîne de caractères en uint16_t
int str_to_uint16(const char *str, uint16_t *res);

#endif